NGINX 1.25 base image

**Don't use in production!!!**