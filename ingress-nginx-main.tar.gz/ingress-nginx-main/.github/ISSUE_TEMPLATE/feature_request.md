---
name: Feature request
about: Suggest an idea for this project or its docs
title: ''
labels: kind/feature
assignees: ''

---

<!-- What do you want to happen? -->

<!-- Is there currently another issue associated with this? -->

<!-- Does it require a particular kubernetes version? -->

<!-- If this is actually about documentation, uncomment the following block -->

<!-- 
/kind documentation
/remove-kind feature
-->
